package me.tycho.NukesPlus;

import java.util.HashMap;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Arrow;
import org.bukkit.plugin.java.JavaPlugin;

import me.tycho.NukesPlus.commands.*;
import me.tycho.NukesPlus.listeners.*;
import me.tycho.NukesPlus.other.*;

public class Main extends JavaPlugin {
	
	public static HashMap<Arrow, Float> arrows = new HashMap<Arrow, Float>();
	
	@Override
	public void onEnable() {
		new MainCommand(this);
		new ArrowShootEvent(this);
		Misc.checkArrows();
		
		Bukkit.addRecipe(Recipes.smallArrowRecipe());
		Bukkit.addRecipe(Recipes.mediumArrowRecipe());
		Bukkit.getServer().broadcastMessage(ChatColor.GREEN + "" + ChatColor.BOLD + "NukesPlus v0.0.1 BETA has been enabled.");
	}
	
	@Override
	public void onDisable() {
		Bukkit.removeRecipe(new NamespacedKey(this, "small_explosive_arrow"));
		Bukkit.removeRecipe(new NamespacedKey(this, "explosive_arrow"));
		Bukkit.getServer().broadcastMessage(ChatColor.RED + "" + ChatColor.BOLD + "NukesPlus has been disabled.");
	}
	
	
}
