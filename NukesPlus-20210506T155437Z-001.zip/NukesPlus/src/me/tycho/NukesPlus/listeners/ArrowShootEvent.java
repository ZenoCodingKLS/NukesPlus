package me.tycho.NukesPlus.listeners;

import org.bukkit.Bukkit;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Arrow;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Fireball;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityShootBowEvent;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;

import me.tycho.NukesPlus.Main;

public class ArrowShootEvent implements Listener{

	@SuppressWarnings("unused")
	private Main plugin;
	private float power;
	
	public ArrowShootEvent(Main plugin) {
		this.plugin = plugin;
		Bukkit.getPluginManager().registerEvents(this, plugin);
	}
	
	@EventHandler
	public void BowEvent(EntityShootBowEvent e) {
		PersistentDataContainer container = e.getConsumable().getItemMeta().getPersistentDataContainer();
		NamespacedKey datakey = new NamespacedKey(Main.getPlugin(Main.class), "explosive");
		
		if(!container.has(datakey, PersistentDataType.STRING)) {
			 return;
		} else if (container.get(datakey, PersistentDataType.STRING).equalsIgnoreCase("small_arrow")) {
			power = 2f;
		} else if (container.get(datakey, PersistentDataType.STRING).equalsIgnoreCase("normal_arrow")) {
			power = 4f;
		}

		Arrow arr = (Arrow) e.getProjectile();
		Fireball fire = (Fireball) arr.getWorld().spawnEntity(arr.getLocation(), EntityType.FIREBALL);
		fire.setYield(power);
		arr.addPassenger(fire);
		Main.arrows.put(arr, power);
		
		
	}
}
