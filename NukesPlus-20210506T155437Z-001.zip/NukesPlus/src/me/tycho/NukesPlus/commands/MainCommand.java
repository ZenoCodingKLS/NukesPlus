package me.tycho.NukesPlus.commands;


import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;


import me.tycho.NukesPlus.Main;
import net.md_5.bungee.api.ChatColor;


public class MainCommand implements CommandExecutor {
	@SuppressWarnings("unused")
	private Main plugin;
	
	public MainCommand(Main plugin) {
		this.plugin = plugin;
		plugin.getCommand("nukesplus").setExecutor(this);
	}
	
	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
			if(args.length == 0) {
				
				sender.sendMessage(ChatColor.GREEN + "You are running " + ChatColor.RED + "NukesPlus v0.0.1 BETA");
				sender.sendMessage(ChatColor.YELLOW + "Run /np help for more info");
			} else if (args[0].equalsIgnoreCase("help")){
				
				sender.sendMessage(ChatColor.RED + "Viewing commands help for NukesPlus v0.0.1 BETA");
				sender.sendMessage(ChatColor.RED + "If you wish for a in-detail tutorial, please type /np usage");
				if(args.length == 1) {
					sender.sendMessage(ChatColor.YELLOW + "--------- Page 1 out of 2 ---------");
					sender.sendMessage(ChatColor.YELLOW + "/np [required] <optional>");
					sender.sendMessage(ChatColor.YELLOW + "/np help <command>");
					sender.sendMessage(ChatColor.GOLD + "Shows this page.");
					
					sender.sendMessage(ChatColor.YELLOW + "/np usage");
					sender.sendMessage(ChatColor.GOLD + "Displays a how-to page, showing the basics of the plugin..");
					
					sender.sendMessage(ChatColor.YELLOW + "/np reload");
					sender.sendMessage(ChatColor.GOLD + "Reloads the config.");
					
					sender.sendMessage(ChatColor.YELLOW + "/np list");
					sender.sendMessage(ChatColor.GOLD + "Lists all activated nukes/features.");
					
					sender.sendMessage(ChatColor.YELLOW + "/np recipe [item]");
					sender.sendMessage(ChatColor.GOLD + "Opens recipe GUI for a specific item.");
					
					sender.sendMessage(ChatColor.YELLOW + "/np give [item] <amount> <player>");
					sender.sendMessage(ChatColor.GOLD + "Shows this page. Amount defaults to 1, player defaults to yourself.");
					
					sender.sendMessage(ChatColor.YELLOW + "/np missle <amount> <power>");
					sender.sendMessage(ChatColor.GOLD + "Gives you a missle. Power defaults to 3. Amount defaults to 1.");
					
					sender.sendMessage(ChatColor.YELLOW + "/np arrow <amount> <power>");
					sender.sendMessage(ChatColor.GOLD + "Reloads the config.");
					
					sender.sendMessage(ChatColor.YELLOW + "/np lockdown <setting>");
					sender.sendMessage(ChatColor.GOLD + "Immidiately disables all nukes. Toggleable.");
					
					sender.sendMessage(ChatColor.YELLOW + "/np gui");
					sender.sendMessage(ChatColor.GOLD + "Opens up the gui interface from there, no commands needed.");
				}
			}
		return false;
	}
}
 
