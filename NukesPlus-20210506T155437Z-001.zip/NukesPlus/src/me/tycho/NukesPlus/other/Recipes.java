package me.tycho.NukesPlus.other;

import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.ShapedRecipe;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import me.tycho.NukesPlus.Main;

public class Recipes {

	public static ShapedRecipe smallArrowRecipe() {
		
		ItemStack item = new ItemStack(Material.ARROW, 6);
		ItemMeta meta = item.getItemMeta();
		NamespacedKey datakey = new NamespacedKey(Main.getPlugin(Main.class), "explosive");
		meta.getPersistentDataContainer().set(datakey, PersistentDataType.STRING, "small_arrow");
		meta.setDisplayName(ChatColor.BLUE + "Small Explosive Arrow");
		item.setItemMeta(meta);
		
		NamespacedKey key = new NamespacedKey(Main.getPlugin(Main.class), "small_explosive_arrow");
		
		ShapedRecipe recipe = new ShapedRecipe(key, item);
		
		recipe.shape("GGG", "AAA", "GGG");
		recipe.setIngredient('G', Material.GUNPOWDER);
		recipe.setIngredient('A', Material.ARROW);
		
		return recipe;
	}

	public static ShapedRecipe mediumArrowRecipe() {
		
		ItemStack item = new ItemStack(Material.ARROW, 2);
		ItemMeta meta = item.getItemMeta();
		NamespacedKey datakey = new NamespacedKey(Main.getPlugin(Main.class), "explosive");
		meta.getPersistentDataContainer().set(datakey, PersistentDataType.STRING, "normal_arrow");
		meta.setDisplayName(ChatColor.BLUE + "Explosive Arrow");
		item.setItemMeta(meta);
		
		NamespacedKey key = new NamespacedKey(Main.getPlugin(Main.class), "explosive_arrow");
		
		ShapedRecipe recipe = new ShapedRecipe(key, item);
		
		recipe.shape(" G ", "GAG", " G ");
		recipe.setIngredient('G', Material.GUNPOWDER);
		recipe.setIngredient('A', Material.ARROW);
		
		return recipe;
	}
	
}	
