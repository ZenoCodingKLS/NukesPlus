package me.tycho.NukesPlus.other;

import java.util.HashMap;

import org.bukkit.Location;
import org.bukkit.entity.Arrow;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.TNTPrimed;
import org.bukkit.scheduler.BukkitScheduler;

import me.tycho.NukesPlus.Main;

public class Misc {
	
	public static void checkArrows() {
		BukkitScheduler sched = Main.getPlugin(Main.class).getServer().getScheduler();
		sched.scheduleSyncRepeatingTask(Main.getPlugin(Main.class), new Runnable() {
				public void run (){
					
					for(HashMap.Entry<Arrow, Float> set: Main.arrows.entrySet()) {
						Arrow i = set.getKey();
						Float power = set.getValue();
						i.setPierceLevel(127);
						
						if(i.isInBlock()) {
							Location loc = i.getAttachedBlock().getLocation();
							TNTPrimed tnt = (TNTPrimed) i.getWorld().spawnEntity(loc, EntityType.PRIMED_TNT);
							tnt.setYield(power);
							i.getServer().getLogger().warning(String.valueOf(tnt.getYield()));
							tnt.setFuseTicks(1);
							i.remove();
							
						}
					}
				}
		}, 0L, 4L);
	}
}
